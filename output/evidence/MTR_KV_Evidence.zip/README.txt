MTR-KV disclosure evidence prepared 21 October 2026.
Extract this archive and run python3 verify_evidence.py to verify file hashes.
Generated input is a controlled demonstration, not a representative dataset.
The paired benchmark uses final-code oracle/indexed paths with identical crop,
storage, model and reuse settings. First 6 of 60 frames are excluded per run.
The full serial trace covers 216 frames. Test report: 128 passes.
Screenshots are actual local browser captures; they are not benchmark runs.
Hashes identify byte content, not independent authenticity or patent priority.
No physical phone, GPU controller, full VLM or production deployment is proved.
Code: create a Python environment, install requirements-live.txt and pytest, then run pytest.
Replicate from code/: PYTHONPATH=. python experiments/benchmark_optimization.py
--input ../input/generated-demo.mp4 --output ../replication-new-directory
Software/runtime packages are not embedded in this archive.
