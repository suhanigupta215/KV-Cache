from hashlib import sha256
import json
from pathlib import Path
root=Path(__file__).resolve().parent
manifest=json.loads((root/'manifest.json').read_text())
for path,expected in manifest['files'].items():
    assert sha256((root/path).read_bytes()).hexdigest()==expected, path
print('Verified',len(manifest['files']),'files')
