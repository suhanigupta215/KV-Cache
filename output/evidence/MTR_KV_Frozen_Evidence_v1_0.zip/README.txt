MTR-KV version 1.0 technical disclosure and evidence baseline, 21 October 2026.
Run python3 verify_evidence.py after extracting to verify every recorded file hash.
The disclosure/ folder contains the matching DOCX and PDF. Preserve these bytes;
make paraphrases and later changes as a new version rather than replacing 1.0.
This is a review baseline, not a patent-office filing or a trusted timestamp.

measurements/ contains the original controlled 216-frame trace, six paired runs,
and the 128-pass test report. The runtime module bytes match the tested build.
measurements/freeze-v1/ contains the three new screenshot-session traces, their
capture-manifest.json, natural-video provenance, both natural traces/evaluations,
and the normalized H264 input. Screenshot timings are not primary benchmarks.
Capture manifest paths refer to the working project: output/evidence corresponds
to screenshots/ here; results/freeze-v1 corresponds to measurements/freeze-v1/.
The three captured endpoint decisions/reuse records match the primary serial run.

The natural input is Big City Life by Coverr, 2015, Wikimedia Commons, listed CC0:
https://commons.wikimedia.org/wiki/File:Big_City_Life.webm
Original VP8 input is under input/. Its SHA1 matches the Commons checksum.
The H264 derivative is 640x360 at 12fps, CRF20, medium preset, GOP48, no B frames,
with audio omitted. Sampling times and both SHA256 values are in the provenance.
Original: 356/356 READY; 100% metadata fallback; zero reuse; 356/356 top1 agreement.
Derivative: 171/171 READY; zero reuse; 170/171 top1 agreement. Frame124 differs.
These single natural-scene runs have no labels and do not prove general accuracy,
reusability, real-time throughput, or optimization speedup across devices.

For measurement reproduction create an environment in code/, install
requirements-live.txt and pytest, then run the archived tests with python -m pytest.
Model weights may need downloading. Use python -m mtr_kv video <input-path>
--semantic-model --kv-inference --kv-reuse --compare-baseline to write a new trace.
For the paired study from code/: PYTHONPATH=. python experiments/benchmark_optimization.py
--input ../input/generated-demo.mp4 --output ../new-replication-directory
For natural-video conversion, copy input/big-city-life-original.webm into code/results/,
then run experiments/validate_real_video.py --prepare-only followed by the same
script without the prepare flag. Document authoring also needs the retained Aura
reference and local authoring assets; the reference document is not redistributed.
No physical phone, GPU/RTL controller or full VLM integration is validated here.
